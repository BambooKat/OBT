import { useEffect, useState } from 'react'
import { Routes, Route, Navigate, useNavigate } from 'react-router-dom'
import { supabase } from './supabaseClient'
import Login from './pages/Login'
import Dashboard from './pages/Dashboard'
import PublicProfile from './pages/PublicProfile'
import ProjectDashboard from './pages/ProjectDashboard'
import ProjectPage from './pages/ProjectPage'
import Layout from './pages/Layout'
import Credits from './pages/Credits'
import Privacy from './pages/Privacy'
import Journal from './pages/Journal'
import JournalEntry from './pages/JournalEntry'
import NoteEditor from './pages/NoteEditor'
import ChecklistPage from './pages/ChecklistPage'
import ChecklistEditor from './pages/ChecklistEditor'
import ChecklistNew from './pages/ChecklistNew'
import Guide from './pages/Guide'
import News from './pages/News'
import VivarexProjects from './pages/vivarex/VivarexProjects'
import VivarexPets from './pages/vivarex/VivarexPets'

function App() {
  const [session, setSession] = useState(null)
  const [loading, setLoading] = useState(true)
  const navigate = useNavigate()

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session)
      setLoading(false)
    })

    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      setSession(session)
      setLoading(false)
    })

    return () => subscription.unsubscribe()
  }, [])

  const handleLogout = async () => {
    await supabase.auth.signOut()
    navigate('/', { replace: true })
  }

  if (loading) {
    return <div style={{ display: 'flex', justifyContent: 'center', marginTop: '40vh' }}>Caricamento...</div>
  }

  // --- NON loggato -------------------------------------------------------
  // Le pagine informative (Guida, FAQ, Novita, Privacy, Crediti) sono pubbliche
  // e usano lo STESSO Layout dei loggati, che si adatta (niente pill-account,
  // mostra Accedi/Registrati). La landing "/" resta Login (ha il suo layout a
  // tutta pagina). Ogni altra rotta -> Login.
  if (!session) {
    return (
      <Routes>
        <Route path="/" element={<Login />} />
        <Route path="/guide" element={<Layout><Guide /></Layout>} />
        <Route path="/faq" element={<Layout><Guide initialTab="faq" /></Layout>} />
        <Route path="/news" element={<Layout><News /></Layout>} />
        <Route path="/privacy" element={<Layout><Privacy /></Layout>} />
        <Route path="/credits" element={<Layout><Credits /></Layout>} />
        {/* contenuti linkabili: lettura pubblica anche senza account (viste read-only) */}
        <Route path="/journal/checklist/:checklistId" element={<Layout><ChecklistPage /></Layout>} />
        <Route path="/journal/:entryId" element={<Layout><JournalEntry /></Layout>} />
        <Route path="/project/:projectId" element={<Layout><ProjectDashboard /></Layout>} />
        <Route path="/line/:id" element={<Layout><ProjectPage /></Layout>} />
        <Route path="/u/:username" element={<Layout><PublicProfile /></Layout>} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    )
  }

  // --- Loggato -----------------------------------------------------------
  const username = session.user?.user_metadata?.username || session.user?.email || ''

  return (
    <Layout username={username} onLogout={handleLogout}>
      <Routes>
        <Route path="/" element={<Navigate to="/dashboard" replace />} />
        <Route path="/journal" element={<Journal />} />
        {/* /new e /checklist/new PRIMA delle rotte :id, sennò "new"/"checklist"
            verrebbero letti come id. Ordine per specificità. */}
        <Route path="/journal/new" element={<NoteEditor />} />
        <Route path="/journal/checklist/new" element={<ChecklistNew />} />
        <Route path="/journal/checklist/:checklistId/edit" element={<ChecklistEditor />} />
        <Route path="/journal/checklist/:checklistId" element={<ChecklistPage />} />
        <Route path="/journal/:entryId/edit" element={<NoteEditor />} />
        <Route path="/journal/:entryId" element={<JournalEntry />} />
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/u/:username" element={<PublicProfile />} />
        <Route path="/project/:projectId" element={<ProjectDashboard />} />
        <Route path="/line/:id" element={<ProjectPage />} />
	<Route path="/vivarex" element={<VivarexProjects />} />
	<Route path="/vivarex/:projectId" element={<VivarexPets />} />
        <Route path="/credits" element={<Credits />} />
        <Route path="/privacy" element={<Privacy />} />
        <Route path="/guide" element={<Guide />} />
        <Route path="/faq" element={<Guide initialTab="faq" />} />
        <Route path="/news" element={<News />} />
        <Route path="*" element={<Navigate to="/dashboard" replace />} />
      </Routes>
    </Layout>
  )
}

export default App
